package com.kh.petner.hotel.model.dao;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import com.kh.petner.hotel.model.vo.Hotel;
import static com.kh.petner.common.JDBCTemplate.*;
public class HotelDao {
	
	private Properties prop;
	
	public HotelDao() {
		prop = new Properties();
		
		String filePath = Hotel.class.getResource("/config/hotel-query.properties").getPath();
		
		try {
			prop.load(new FileReader(filePath));
		}catch(IOException e) {
			e.printStackTrace();
		}
	}

	public ArrayList<Hotel> selectList(Connection con) {
		ArrayList<Hotel> list = null;
		Statement stmt = null;
		ResultSet rset = null;
		
		String sql = prop.getProperty("selectList");
		
		try {
			
			stmt = con.createStatement();
			rset = stmt.executeQuery(sql);
			
			
			System.out.println("쿼리문이 똑바로 작동한다면 다음에 와일문이 나올거임");
			list = new ArrayList<Hotel>();
			
			while(rset.next()){
				System.out.println("while문들어옴");	
				
				Hotel h = new Hotel();
				
				h.setHotel_num(rset.getInt(1));
				h.setHotel_name(rset.getString(2));
				
				list.add(h);
			}
			
		}catch(SQLException e) {
			e.printStackTrace();
		}finally {
			close(rset);
			close(stmt);
		}
		
		return list;
	}
	
}
